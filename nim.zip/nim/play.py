from nim import train, play

ai = train(10000)
play(ai)
